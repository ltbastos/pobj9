Coloque aqui arquivos do conhecimento do POBJ:
- .txt (texto puro)
  - .pdf (se 'pdftotext' estiver instalado no servidor)
- .csv (primeira linha como cabeçalhos)
- .json (será convertido para texto com JSON_PRETTY_PRINT)

  Dica: se PDF não puder ser convertido no servidor, exporte para .txt e coloque aqui.

Após atualizar esta pasta, o painel reconstrói automaticamente o arquivo
`docs/knowledge.index.json` na primeira pergunta enviada ao agente.